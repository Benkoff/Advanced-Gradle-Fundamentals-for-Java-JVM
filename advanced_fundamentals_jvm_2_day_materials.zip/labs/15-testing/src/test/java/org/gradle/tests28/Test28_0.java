package org.gradle.tests28;

import org.junit.Test;

public class Test28_0 {
    @Test
    public void myTest() throws Exception {
        Thread.sleep(5);
    }
}