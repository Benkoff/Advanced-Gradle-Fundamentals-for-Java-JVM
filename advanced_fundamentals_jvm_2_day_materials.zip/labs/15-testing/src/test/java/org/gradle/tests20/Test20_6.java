package org.gradle.tests20;

import org.junit.Test;

public class Test20_6 {
    @Test
    public void myTest() throws Exception {
        Thread.sleep(5);
    }
}