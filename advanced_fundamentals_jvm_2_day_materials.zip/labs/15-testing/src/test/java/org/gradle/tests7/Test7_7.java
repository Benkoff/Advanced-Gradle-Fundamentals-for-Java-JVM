package org.gradle.tests7;

import org.junit.Test;

public class Test7_7 {
    @Test
    public void myTest() throws Exception {
        Thread.sleep(5);
    }
}