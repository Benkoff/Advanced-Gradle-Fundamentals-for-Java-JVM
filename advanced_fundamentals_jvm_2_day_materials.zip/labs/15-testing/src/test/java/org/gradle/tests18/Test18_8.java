package org.gradle.tests18;

import org.junit.Test;

public class Test18_8 {
    @Test
    public void myTest() throws Exception {
        Thread.sleep(5);
    }
}