package org.gradle.tests14;

import org.junit.Test;

public class Test14_1 {
    @Test
    public void myTest() throws Exception {
        Thread.sleep(5);
    }
}