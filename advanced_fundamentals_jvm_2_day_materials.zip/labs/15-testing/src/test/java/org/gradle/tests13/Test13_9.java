package org.gradle.tests13;

import org.junit.Test;

public class Test13_9 {
    @Test
    public void myTest() throws Exception {
        Thread.sleep(5);
    }
}