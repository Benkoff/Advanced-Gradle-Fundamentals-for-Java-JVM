package org.gradle.tests25;

import org.junit.Test;

public class Test25_3 {
    @Test
    public void myTest() throws Exception {
        Thread.sleep(5);
    }
}