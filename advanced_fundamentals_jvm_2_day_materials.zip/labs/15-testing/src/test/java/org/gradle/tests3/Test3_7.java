package org.gradle.tests3;

import org.junit.Test;

public class Test3_7 {
    @Test
    public void myTest() throws Exception {
        Thread.sleep(5);
    }
}