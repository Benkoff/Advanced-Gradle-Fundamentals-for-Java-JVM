package org.gradle.tests23;

import org.junit.Test;

public class Test23_8 {
    @Test
    public void myTest() throws Exception {
        Thread.sleep(5);
    }
}