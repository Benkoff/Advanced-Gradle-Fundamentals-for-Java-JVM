package org.gradle.tests3;

import org.junit.Test;

public class Test3_2 {
    @Test
    public void myTest() throws Exception {
        Thread.sleep(5);
    }
}