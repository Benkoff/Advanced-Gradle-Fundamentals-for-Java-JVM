package org.gradle.tests6;

import org.junit.Test;

public class Test6_1 {
    @Test
    public void myTest() throws Exception {
        Thread.sleep(5);
    }
}