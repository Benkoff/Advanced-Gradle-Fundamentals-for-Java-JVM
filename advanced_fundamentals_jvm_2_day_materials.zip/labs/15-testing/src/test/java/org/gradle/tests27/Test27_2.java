package org.gradle.tests27;

import org.junit.Test;

public class Test27_2 {
    @Test
    public void myTest() throws Exception {
        Thread.sleep(5);
    }
}