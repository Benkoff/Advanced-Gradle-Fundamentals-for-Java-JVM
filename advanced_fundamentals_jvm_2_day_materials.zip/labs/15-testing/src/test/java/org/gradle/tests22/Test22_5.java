package org.gradle.tests22;

import org.junit.Test;

public class Test22_5 {
    @Test
    public void myTest() throws Exception {
        Thread.sleep(5);
    }
}