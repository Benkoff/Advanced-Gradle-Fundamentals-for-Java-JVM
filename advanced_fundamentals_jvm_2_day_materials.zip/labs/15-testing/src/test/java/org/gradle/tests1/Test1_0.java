package org.gradle.tests1;

import org.junit.Test;

public class Test1_0 {
    @Test
    public void myTest() throws Exception {
        Thread.sleep(5);
    }
}