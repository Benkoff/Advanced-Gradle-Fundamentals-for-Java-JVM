package org.gradle;

public class Person {}
